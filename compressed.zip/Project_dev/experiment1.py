# identifier , variables , data types

a = 10 #int
b = 10.2 #float
c = 'c' #string
d = 10.32156 #double
e = 11.123456789123456789456 # double
f = d+e

print(" sum = " , (a+b))
print("char = ",c)
print("double sum = ",f)
print(type(a))
print(type(b))
print(type(c))
print(type(d))
print(type(e))
print(type(f))
type(print(print("")))

