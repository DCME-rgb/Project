# print("enter 0 or 1 :")
# a = True
# b = False
c = bool(input("enter 0 or 1 : "))
d = bool(input("enter 0 or 1 : "))
e = c and d
f = c or d
print("AND = ",e)
print("OR = ",f)
   
        