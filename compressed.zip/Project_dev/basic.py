#list
list = [ 's' ,"a",1,2,3]
print(list)
print(type(list[0]))
print(type(list[1]))
print(type(list[2]))
print(type(list[3]))


