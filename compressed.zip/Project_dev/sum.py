a = int(input("enter a value:"))
b = int(input("enter b value:"))
c = a+b
print("addition of " , a , " and " , b , " is :",c)