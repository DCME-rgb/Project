# NORMAL CLASS
'''class Baseoops:
    def display(self):
        print("i am under the water")

obj = Baseoops()
obj.display()'''

# constructor 
'''class con:
    
# default constructor
    def __init__(self):
        print("i am under the default constructor ")

# parameter constructor
    def __init__(self,a):
        print("they entered a is :",a)

obj2 = con(10) '''

# inheritance 
# single inheritance 
'''class Base:
    def base(self):
        print("Base class belonged")

class Derive(Base):
    def Der(self):
       
        print("Derived Class Belonged")

obj = Derive()
obj.base()
obj.Der()'''

# multiple inheritance

'''class Base1:
    def base1(self):
        print("base1")

class Base2:
    def base2(self):
        print("base2")

class Derived(Base1,Base2):
    def der(self):
        print("derived class")

obj = Derived()
obj.base1()
obj.base2()
obj.der()'''

# multilevel inheritance 

'''class Base:
    def base(self):
        print("Base class belonged")

class Derive1(Base):
    def Der(self):
       
        print("Derived Class Belonged")

class Derive2(Derive1):
    def Der2(self):

        print("derive to derive")


obj = Derive2()
obj.base()
obj.Der()
obj.Der2()'''

#  Hierarchial inheritance 

# class Base:
#     def base(self):
#         print("Base class belonged")

# class Derive1(Base):
#     def Der1(self):
#         print("Derived1 Class Belonged")

# class Derive2(Base):
#     def Der2(self):
#         print("Derived2 Class Belonged")

# class Derive3(Base):
#     def Der3(self):    
#         print("Derived3 Class Belonged")

# obj = Derive3()
# obj.base()
# obj.Der1()
# obj.Der2()
# obj.Der3()

def add(a,b):
    c = int(a+b)
    print(c)

def add(a,b,c):
    d = int(a+b+c)
    print(d)


add(10,20)
add(12,12,22)





