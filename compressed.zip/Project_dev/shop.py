class book:
    def __init__(self):
        total= 0
        b1 = 100
        b2 = 200
        b3 = 300
        
    def order(self):
        print("order only one item")
        o1 = input("please enter your order b1,b2 and b3")
        if( o1 == b1):
            total +=b1
        elif(o1 == b2):
            total += b2
        elif(01 == b3):
            total += b3

    def bill(self):
        print("your bill is : "+total)


obj = book
book.order()
book.bill()

        
