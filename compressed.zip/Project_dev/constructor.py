class CSE:
    def __init__(self):
        print("hello world")

obj1 = CSE()
