# class BMS:
#     name = ""
#     accountno = {}
#     balance  = {}
#     deposit = {}
#     def __init__(self):
#         balance = 1000
#
#     def details(self):
#         name = input("enter your name:")
#         accountno = input("enter your account number:")
#         deposit = int( input("enter the amount to deposit:"))
#         self.balance +=deposit
#
#     def display(self):
#         print("NAME:",self.name)
#         print("Account No:",self.accountno)
#
#     #main code
#     obj = BMS()
# class BMS:
#     name = ""
#     accountno = ""
#     balance = 1000
#     deposit = 0
#
#     def __init__(self):
#         pass
#
#     def details(self):
#         self.name = input("Enter your name: ")
#         self.accountno = input("Enter your account number: ")
#         self.deposit = int(input("Enter the amount to deposit: "))
#         self.balance += self.deposit
#
#     def display(self):
#         print("NAME:", self.name)
#         print("Account No:", self.accountno)
#         print("Balance:", self.balance)
#
# # main code
# obj = BMS()
# obj.details()
# obj.display()

# class BMS:
#     def __init__(self):
#         self.name = ""
#         self.accountno = ""
#         self.balance = 1000
#         self.deposit = 0
#
#     def details(self):
#         self.name = input("Enter your name: ")
#         self.accountno = input("Enter your account number: ")
#         self.deposit = int(input("Enter the amount to deposit: "))
#         self.balance += self.deposit
#
#     def display(self):
#         print("NAME:", self.name)
#         print("Account No:", self.accountno)
#         print("Balance:", self.balance)
#
# # main code
# obj = BMS()
# a = int(input("enter your choice:"))
#  match a:
#      case 1 :
#     obj.details()
#      case 2 :
#     obj.display()
#      case _:
#     print("unknown choice")

class BMS:
    def __init__(self):
        self.name = ""
        self.accountno = ""
        self.balance = 1000
        self.deposit = 0

    def details(self):
        self.name = input("Enter your name: ")
        self.accountno = input("Enter your account number: ")
        self.deposit = int(input("Enter the amount to deposit: "))
        self.balance += self.deposit

    def display(self):
        print("NAME:", self.name)
        print("Account No:", self.accountno)
        print("Balance:", self.balance)

# main code
obj = BMS()
a = int(input("Enter your choice: "))
if a == 1:
    obj.details()
elif a == 2:
    obj.display()
else:
    print("Unknown choice")