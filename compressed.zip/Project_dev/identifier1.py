a = "xyz"
b = "123"
c = "_a"
d = "a+b"
e = "_"
f = "var_1"
g = "1_var"
h = "var 1"
i = "var+1"
j = "___abc____"
k = "_1"
l = "__#"
print(a.isidentifier())
print(b.isidentifier())
print(c.isidentifier())
print(d.isidentifier())
print(e.isidentifier())
print(f.isidentifier())
print(g.isidentifier())
print(h.isidentifier())
print(i.isidentifier())
print(j.isidentifier())
print(k.isidentifier())
print(l.isidentifier())
