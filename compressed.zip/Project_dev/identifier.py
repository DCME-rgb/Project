number1 = 51
number2 = 52
number3 = 53
number4 = 54
number5 = 55
number6 = 56
number7 = 57
number8 = 58
number9 = 59
number10 = 50
name1 = "tejesh"
name2 = "ganesh"
name3 = "lucky"
name4 = "guru"
name5 = "jaya"
print(name1)


