class C :
    #member functions
    def function(self):
        print("hello world")
    def prend(self,a,b):
        print("sum ",a+b)
   #constructor
    def __init__(self):
        print("i am a constructor")
    #parameter constructor


#member function out of the class
def fun():
    print("hello i am out of the class")



object = C()
object.function()
object.prend(10,20)
fun()
