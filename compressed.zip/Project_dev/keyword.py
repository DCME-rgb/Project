a = int(input("Enter your choice: "))
if a == 1:
    print("ONE")
elif a == 2:
    print("TWO")
else:
    print("ABOVE 2")