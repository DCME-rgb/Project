class student:
      def __init__(self):
             self.rollno = ""
             self.branch = ""
             self.name = ""
             self.phoneno = ""

      def getdata(self):
             name =   input("enter your name: ")
             rollno = input("enter your roll number: ")
             branch = input("enter your branch: ")
             phone =  input("enter your number: ")

      def display(self):
             print("Name = ",self.name)
             print("Roll Number =",self.rollno)
             print("Branch = ",self.branch)
             print("Phone Number = ",self.phone)

obj = student()
obj.getdata()
obj.display()