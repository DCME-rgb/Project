# Open the file in write mode
with open('PYTHON/hello_world.txt', 'w') as file:
    # Write "Hello World" to the file
    file.write('Hello World')

# Confirm the operation
print("File created and 'Hello World' written successfully.")
